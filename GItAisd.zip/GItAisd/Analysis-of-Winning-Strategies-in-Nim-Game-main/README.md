# Analysis-of-Winning-Strategies-in-Nim-Game
Implementation and mathematical analysis of winning strategies in the classical Nim game using game theory principles.



## Код программы

- [Исходный код](src/NimGame.java) - консольное приложение для анализа игры Ним
- [Тесты](test/NimGameTest.java) - юнит-тесты для проверки алгоритма
